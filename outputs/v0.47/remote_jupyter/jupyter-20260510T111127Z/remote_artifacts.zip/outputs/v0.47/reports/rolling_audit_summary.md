> version: v0.47
> experiment_id: v0.47-fdb00545
> config_hash: fdb00545c6611582b09096325a7dba3890362251cb1e482326ef83f8c8ee9b0a
> run_timestamp: 2026-05-10T11:04:42+00:00
> device: cuda
> data_range: 2025-11-01 00:00:00 -> 2026-03-20 23:45:00

# 滚动回测审计摘要

- 窗口数: 10
- 调度文件: metrics/rolling_window_schedule.csv
- 参数快照: metrics/rolling_parameter_snapshots.csv
- 验证指标: metrics/rolling_validation_metrics.csv
- 回测指标: metrics/rolling_backtest_metrics.csv
- 周度回测明细: metrics/rolling_weekly_results.csv
- 超额收益验证: metrics/rolling_excess_return_metrics.csv
- 基准比较: metrics/benchmark_comparison.csv
- 消融结果: metrics/ablation_metrics.csv
- 稳健性结果: metrics/robustness_metrics.csv
- 约束激活报告: reports/constraint_activation_report.md
